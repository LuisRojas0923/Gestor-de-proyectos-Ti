// Exportar el sistema de logging
export { logger, development, phases, api, modal, validation, debug } from './logger';
