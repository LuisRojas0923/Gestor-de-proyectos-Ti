// Exportación de componentes de desarrollo
export { default as DevelopmentPhases } from './DevelopmentPhases';
export { default as DevelopmentStageProgress } from './DevelopmentStageProgress';
export { default as DevelopmentTimeline } from './DevelopmentTimeline';

