"""
Servicios de negocio del Sistema de Gestión de Proyectos TI
Estructura modular según arquitectura
"""
